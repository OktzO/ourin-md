import axios from 'axios';

/**
 * Mesin Pencari Musik AzusaMD V0 (Deezer Studio Catalog + Apple iTunes HD)
 * Menghasilkan link preview MP3 asli dan cover album beresolusi tinggi 500x500.
 */
export async function searchSpotifyTrack(query) {
  if (!query || typeof query !== 'string') return null;

  const cleanQuery = query
    .replace(/https?:\/\/open\.spotify\.com\/(intl-[a-z]+\/)?track\/[a-zA-Z0-9]+(\?.*)?/i, '')
    .trim() || query.trim();

  // 1. Prioritas Utama: Deezer Search API
  try {
    const dzRes = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(cleanQuery)}&limit=1`, {
      timeout: 8000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      }
    });

    const dzItem = dzRes.data?.data?.[0];
    if (dzItem && dzItem.preview) {
      const cover = dzItem.album?.cover_big || dzItem.album?.cover_medium || dzItem.album?.cover_xl || '';
      return {
        title: dzItem.title || 'Unknown Title',
        artist: dzItem.artist?.name || 'Unknown Artist',
        album: dzItem.album?.title || 'Single',
        coverUrl: cover,
        audioUrl: dzItem.preview,
        trackUrl: dzItem.link || `https://www.deezer.com/track/${dzItem.id}`,
        durationMs: (dzItem.duration || 30) * 1000,
        durationSec: dzItem.duration || 30,
        source: 'deezer'
      };
    }
  } catch (dzErr) {
    // Fallback ke iTunes jika Deezer mengalami timeout / kendala jaringan
  }

  // 2. Prioritas Cadangan: Apple iTunes Search API
  try {
    const itUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(cleanQuery)}&media=music&limit=1`;
    const itRes = await axios.get(itUrl, {
      timeout: 8000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      }
    });

    const itItem = itRes.data?.results?.[0];
    if (itItem && itItem.previewUrl) {
      const coverHd = (itItem.artworkUrl100 || '').replace('100x100bb', '500x500bb');
      const durSec = Math.floor((itItem.trackTimeMillis || 30000) / 1000);
      return {
        title: itItem.trackName || 'Unknown Title',
        artist: itItem.artistName || 'Unknown Artist',
        album: itItem.collectionName || 'Single',
        coverUrl: coverHd,
        audioUrl: itItem.previewUrl,
        trackUrl: itItem.trackViewUrl || 'https://music.apple.com',
        durationMs: itItem.trackTimeMillis || 30000,
        durationSec: durSec || 30,
        source: 'itunes'
      };
    }
  } catch (itErr) {
    // Keduanya gagal
  }

  return null;
}

/**
 * Mengunduh buffer gambar cover dan file audio MP3 secara paralel
 */
export async function downloadTrackBuffers(track) {
  let coverBuf = null;
  let audioBuf = null;

  try {
    const [coverRes, audioRes] = await Promise.all([
      track.coverUrl
        ? axios.get(track.coverUrl, { responseType: 'arraybuffer', timeout: 10000 }).catch(() => null)
        : null,
      track.audioUrl
        ? axios.get(track.audioUrl, { responseType: 'arraybuffer', timeout: 15000 }).catch(() => null)
        : null
    ]);

    if (coverRes?.data) coverBuf = Buffer.from(coverRes.data);
    if (audioRes?.data) audioBuf = Buffer.from(audioRes.data);
  } catch {
    // Tangani kemungkinan error fetch
  }

  return { coverBuf, audioBuf };
}

export default {
  searchSpotifyTrack,
  downloadTrackBuffers
};
