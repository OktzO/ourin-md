import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@sairidev/baileys-new';
import pino from 'pino';
import readline from 'readline';
import { searchSpotifyTrack, downloadTrackBuffers } from './src/services/spotify.service.js';
import { sendInlineWebUI, getSpotifyInlineHtml } from './src/services/webui.service.js';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (query) => new Promise((resolve) => rl.question(query, resolve));

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('session');

  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: ['Ubuntu', 'Chrome', '20.0.04']
  });

  // Handler Pairing Code melalui Terminal
  if (!sock.authState.creds.registered) {
    console.log('\n=============================================');
    console.log('🤖 AZUSAMD V0 — SPOTIFY MUSIC SUITE (.play & .play2)');
    console.log('=============================================');
    const phoneNumber = await question('📱 Masukkan nomor WhatsApp Anda (contoh: 62895xxxx): ');
    const code = await sock.requestPairingCode(phoneNumber.trim());
    console.log(`\n🔑 KODE PAIRING ANDA: [ ${code} ]\n`);
  }

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'open') {
      console.log('\n=============================================');
      console.log('✅ Bot AzusaMD V0 Berhasil Terhubung!');
      console.log('🎵 Menu Aktif:');
      console.log('   • .play <judul>   -> Audio WhatsApp langsung');
      console.log('   • .play2 <judul>  -> Kartu Spotify WebUI interaktif');
      console.log('=============================================\n');
    }
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) {
        console.log('⚠️ Koneksi terputus, mencoba menghubungkan kembali...');
        startBot();
      } else {
        console.log('❌ Sesi telah keluar (logged out). Hapus folder session dan lakukan pairing ulang.');
      }
    }
  });

  // Router Khusus: Hanya memproses perintah musik .play dan .play2
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    try {
      const msg = messages[0];
      if (!msg || !msg.message || msg.key.fromMe) return;

      const from = msg.key.remoteJid;
      const rawText = (
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        msg.message.imageMessage?.caption ||
        ''
      ).trim();

      if (!rawText) return;

      // Parsing prefix (. ! # /)
      const prefix = ['.', '!', '#', '/'].find(p => rawText.startsWith(p)) || '';
      const body = prefix ? rawText.slice(prefix.length).trim() : rawText;
      const [cmd, ...args] = body.split(/\s+/);
      const command = (cmd || '').toLowerCase();
      const query = args.join(' ').trim();

      // Filter ketat: Hanya merespons 'play' dan 'play2'
      if (command !== 'play' && command !== 'play2') {
        return;
      }

      // Panduan jika diketik tanpa menyertakan judul lagu
      if (!query) {
        const guideText = 
          `🎵 *AZUSAMD V0 — SPOTIFY MUSIC SUITE*\n\n` +
          `Daftar Perintah:\n` +
          `• *${prefix || '.'}play <judul>* : Kirim langsung pesan audio pemutar lagu WhatsApp\n` +
          `• *${prefix || '.'}play2 <judul>* : Kirim kartu Spotify WebUI interaktif di chat\n\n` +
          `Contoh Penggunaan:\n` +
          `• *${prefix || '.'}play the shade*\n` +
          `• *${prefix || '.'}play2 about you the 1975*`;

        return await sock.sendMessage(from, { text: guideText }, { quoted: msg });
      }

      console.log(`[REQUEST] Perintah: .${command} | Query: "${query}" dari ${from}`);

      // 1. Cari Metadata Lagu via Deezer / iTunes API
      const track = await searchSpotifyTrack(query);
      if (!track) {
        return await sock.sendMessage(from, {
          text: `❌ Maaf, lagu "${query}" tidak ditemukan. Coba gunakan judul atau nama artis yang lebih spesifik.`
        }, { quoted: msg });
      }

      // 2. Unduh Buffer Cover & Audio MP3
      const { coverBuf, audioBuf } = await downloadTrackBuffers(track);

      // ==========================================
      // KASUS A: .play2 (Kartu Spotify WebUI Interaktif)
      // ==========================================
      if (command === 'play2') {
        const base64Cover = coverBuf 
          ? `data:image/jpeg;base64,${coverBuf.toString('base64')}` 
          : (track.coverUrl || '');

        const base64Audio = audioBuf 
          ? `data:audio/mp3;base64,${audioBuf.toString('base64')}` 
          : (track.audioUrl || '');

        const playerHtml = getSpotifyInlineHtml({
          title: track.title,
          artist: track.artist,
          album: track.album,
          coverUrl: base64Cover,
          audioUrl: base64Audio,
          durationSec: track.durationSec || 30
        });

        await sendInlineWebUI(sock, from, playerHtml, `${track.title} - ${track.artist}`);
        console.log(`[SUKSES] .play2 dikirim: "${track.title}" ke ${from}`);
        return;
      }

      // ==========================================
      // KASUS B: .play (Audio Langsung Pemutar Lagu WhatsApp)
      // ==========================================
      if (command === 'play') {
        if (!audioBuf) {
          return await sock.sendMessage(from, {
            text: `❌ Gagal mengunduh audio preview. Anda dapat mendengarkan lagu di:\n${track.trackUrl || 'https://open.spotify.com'}`
          }, { quoted: msg });
        }

        const isMp3 = audioBuf.slice(0, 3).toString('ascii') === 'ID3' || 
                      audioBuf.slice(0, 2).toString('hex') === 'fffb' || 
                      audioBuf.slice(0, 2).toString('hex') === 'fffa';
        const correctMime = isMp3 ? 'audio/mpeg' : 'audio/mp4';

        await sock.sendMessage(from, {
          audio: audioBuf,
          mimetype: correctMime,
          ptt: false,
          fileName: `${track.title} - ${track.artist}.mp3`,
          contextInfo: {
            externalAdReply: {
              title: track.title,
              body: `${track.artist} • ${track.album}`,
              thumbnail: coverBuf || undefined,
              thumbnailUrl: track.coverUrl,
              mediaType: 1,
              sourceUrl: track.trackUrl || 'https://open.spotify.com',
              renderLargerThumbnail: true,
              showAdAttribution: true
            }
          }
        }, { quoted: msg });

        console.log(`[SUKSES] .play dikirim: "${track.title}" ke ${from}`);
      }
    } catch (err) {
      console.error(`[ERROR] Gagal memproses perintah:`, err.message);
    }
  });
}

startBot();
