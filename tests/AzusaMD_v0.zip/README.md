# 🎵 AzusaMD V0 — Dedicated Spotify Music Suite (.play & .play2)

Versi paling ringan, bersih, dan cepat dari **AzusaMD** yang dibuat khusus secara eksklusif hanya untuk pemutar musik WhatsApp:
1. **`.play <judul>`** : Mengirim file audio pemutar lagu langsung di chat WhatsApp dengan cover album HD & *rich externalAdReply banner*.
2. **`.play2 <judul>`** : Mengirim kartu Spotify WebUI interaktif langsung di dalam balon chat WhatsApp (protokol Meta AI `GenAIaeacdsnwHtmlPrimitive`) lengkap dengan seekbar sentuh real-time, tombol play/pause, loop, like, dan audio playback.

> ⚡ **Zero-Bloat Guarantee:** Tanpa game, tanpa sistem moderasi grup, tanpa database SQLite rumit. Hanya berfokus 100% pada pengalaman mendengarkan musik terbaik di WhatsApp.

---

## 📁 Struktur File Sederhana

```text
AzusaMD_v0/
├── src/
│   └── services/
│       ├── spotify.service.js    # Mesin pencari katalog Deezer & iTunes HD
│       └── webui.service.js      # Generator Spotify WebUI Card & Meta AI Primitive
├── index.js                      # Baileys Socket, Pairing Code & Router Musik
├── package.json                  # Dependensi super minimalis (hanya 3 package)
├── .env.example
├── .gitignore
└── README.md
```

---

## 🚀 Cara Menjalankan

### 1. Pasang Dependensi
Buka terminal di folder ini, lalu jalankan:
```bash
npm install
```

### 2. Jalankan Bot
```bash
npm start
```

### 3. Tautkan Akun WhatsApp (Pairing Code)
1. Terminal akan meminta nomor WhatsApp Anda:
   ```text
   📱 Masukkan nomor WhatsApp Anda (contoh: 62895xxxx): 
   ```
2. Salin **8-digit Kode Pairing** yang muncul di terminal.
3. Buka WhatsApp di HP Anda > **Perangkat Tertaut** > **Tautkan dengan nomor telepon** > Masukkan 8-digit kode tersebut.
4. Selesai! Bot AzusaMD V0 langsung aktif dan siap digunakan.

---

## 🎧 Cara Menggunakan Perintah

| Perintah | Deskripsi | Tipe Output |
| :--- | :--- | :--- |
| **`.play <judul>`** | Memutar musik audio asli WhatsApp | Pesan Audio WhatsApp (`audio/mpeg`) + Rich AdReply Thumbnail |
| **`.play2 <judul>`** | Memutar musik kartu interaktif | Kartu Spotify WebUI di dalam chat dengan slider seekbar sentuh |

### Contoh Penggunaan:
- `.play the shade`
- `.play2 about you the 1975`
- `.play komang raim laode`
- `.play2 ghost justin bieber`

*Jika Anda mengetik `.play` atau `.play2` saja tanpa judul, bot akan otomatis mengirimkan panduan singkat.*

---

## 📜 Lisensi
MIT License — AzusaMD V0 by Rozzak.
